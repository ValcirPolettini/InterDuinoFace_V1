# AUTHORS | arduino-ad-mux-lib
Project arduino-ad-mux-lib (https://github.com/stechio/arduino-ad-mux-lib)

## MAIN CONTRIBUTORS
* Stefano Chizzolini (@stechio, https://github.com/stechio): main developer
* Nick Lamprianidis (@nlamprian, https://github.com/nlamprian): original code base developer (see Project MUX74HC4067, https://github.com/nlamprian/MUX74HC4067)

## OTHER CONTRIBUTORS
* Thijs Triemstra (@thijstriemstra, https://github.com/thijstriemstra): ESP32 support and Travis CI introduction (version 3)